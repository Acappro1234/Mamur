1.3.0 / Jun 02, 2023
==================
  * Added support for multiple character sets
  * Removed dependency on array-uniq

1.2.3 / Oct 20, 2022
==================
  * Fixed React support
  * Fixed unexpected behavior of length option

1.2.2 / Jan 22, 2022
==================
  * Fixed browser support

1.2.1 / May 10, 2021
==================
  * Fixed tests

1.2.0 / May 10, 2021
==================
  * Use randombytes instead of node.crypto to prevent biased output
  * Add support for async generation
  * Support for binary and octal charsets

1.1.5 / May 18, 2016
==================
  * Optimized character generation algorithm

1.1.4 / Feb 10, 2016
==================
  * Added option for capitalization

1.1.3 / Nov 03, 2015
==================
  * Fixed test

1.1.2 / Nov 03, 2015
==================
  * Added command line support
  * Fixed bug causing the "readable" option to fail

1.1.0 / Sep 06, 2015
==================
  * Added support for custom character sets
  * Added option for excluding poorly readable characters

1.0.8 / Sep 01, 2015
==================
  * Avoid problems if crypto.randomBytes throws an exception

1.0.7 / Jul 03, 2015
==================
  * Use node.crypto instead of Math.random as random number generator

1.0.6 / Jun 01, 2015
==================
  * Added licence for npmjs.org
  * Enhanced readme for Github and npm

1.0.5 / Apr 03, 2015
==================
  * Better charset setting → Less error-proneness

1.0.4 / Apr 03, 2015
==================
  * Added tests

1.0.3 / Feb 17, 2014
==================
  * Fixed typo in character set

1.0.0 / Jan 21, 2012
==================
  * Start of the project