sudo apt-get install golang
pkg install golang
sudo apt-get update && sudo apt-get upgrade
apt-get update && apt-get upgrade
sudo apt-get install screen
pkg install screen
sudo apt-get install openjdk-8-jdk
pkg install openjdk-17
sudo apt-get install wget
pkg install wget
sudo apt-get install python3
pkg install python3
sudo apt-get install python3-pip
pkg install python3-pip && pkg install python-pip
sudo apt-get install requests
pip install requests
sudo apt-get install npm
pkg install npm && pip install npm
sudo apt-get install nodejs
pkg install nodejs && pip install nodejs
pip3 install golang
npm install -g npm@10.2.3
npm i requests
npm i https-proxy-agent
npm i crypto-random-string
npm i events
npm i fs
npm i net
npm i cloudscraper
npm i request
npm i hcaptcha-solver
npm i randomstring
npm i cluster
npm i random-useragent
npm i set-cookie-parser
npm i cloudflare-bypasser
npm i http2
npm i tls
npm i cluster
npm i url 
npm i crypto
npm i axios
npm i cheerio
npm i gradient-string
npm i fake-useragent
npm audit fix
pip3 install -r requirements.txt
pip install -r requirements.txt
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo apt-get install ./google-chrome-stable_current_amd64.deb
ulimit -n 999999
chmod 777 *